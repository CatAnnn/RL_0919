# 复现状态

## 当前任务
- 范围：图5—10，指定pytorch_env，真实实验与严格验收。
- 执行状态：已完成代码、13项单元测试、冒烟、20次完整训练、评估、六图和五种子报告。
- 科学状态：严格论文复现未通过；工程真实性与一致性审计通过。不能将任务目标标为已实现。

## 产物索引
| 产物 | 路径 | 状态 |
|---|---|---|
| 规格和公式 | paper_spec.md、discrepancy_register.md | PDF图像已核对 |
| 参数假设 | assumptions.yaml、configs/ | 工程参数明确标注 |
| 表I/II | data/ | 原表24点保留 |
| 测试 | evidence/unit_tests.txt、evidence/smoke_audit.json | 通过 |
| 完整训练 | logs/main_seed0至main_seed4、checkpoints/ | 4算法各1500次 |
| 主调度与检查点评估 | logs/main_seed0/evaluation/ | 7个真实检查点 |
| 六图 | figures/main_seed0/index.html | PNG/PDF/SVG |
| 稳定性 | logs/stability_summary.csv | 五种子均值与样本标准差 |
| 审计/验收 | evidence/delivery_audit.json、evidence/acceptance.json | 工程通过，科学未通过 |
| 差异报告 | reproduction_report.md | 逐图实际结果与限制 |

## 已确认决策
- 一套预登记配置，种子0—4；主图始终种子0，无图形拟合、无最优种子挑选。
- 确定性表II场景，初始SOC0.5，局部5维历史状态；策略潜均值经tanh映射。
- 图5/10共用原始episode sum；平滑25且不跨500/1000边界。
- 图6—8为1500 pre_fed；图9为1/50/500/700/900/1400，500 pre_fed。
- 完整训练共2,160,000条智能体转移；配置哈希在各日志metadata中，模型含优化器和随机数状态。

## 缺口与后续
- 论文未公开的奖励权重、电池容量/SOC/效率、网络、动作分布、采样与统计口径尚未取得。
- 图9 MG1第1400次失衡为6126.946，论文约3000；逐图失败项见报告。
- 五种子F-MADRL训练排序胜出6/15，不能复述为全面优于基线。
- 高斯误差的固定检查点评估已执行；高斯完整训练未执行；未开展额外参数搜索。
- 继续工作应先取得作者配置/代码/指标定义，或明确新的假设敏感性实验；不能修改表II或奖励去拟合图片。
